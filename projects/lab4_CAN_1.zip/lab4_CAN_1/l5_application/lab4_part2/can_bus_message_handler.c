#include "can_bus_message_handler.h"

#include "can_bus.h"
#include <stddef.h>
#include <stdint.h>

static can__msg_t can_message1 = {0};
static can__msg_t can_message2 = {0};

void can_bus_handle(void) {

  can_message1.msg_id = 1;
  can_message1.data = (can__data_t){5};

  can__tx(can1, &can_message1, 100);

  while (can__rx(can1, &can_message2, 100)) {
    printf("Message ID: %d", can_message2.msg_id);
  }
}