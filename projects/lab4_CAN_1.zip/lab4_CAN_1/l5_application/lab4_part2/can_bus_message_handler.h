#pragma once

void can_bus_handle(void);