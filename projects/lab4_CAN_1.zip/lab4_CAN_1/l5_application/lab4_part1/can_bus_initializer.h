#pragma once

#include <stddef.h>
#include <stdint.h>

void callback_BusOFF(uint32_t parameter1);
void callback_OverRun(uint32_t parameter1);

void can_initial(void);