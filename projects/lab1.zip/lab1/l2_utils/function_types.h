#pragma once

typedef void (*function__void_f)(void);
typedef void (*function__task_f)(void *param);